export default shuffle;
/**
 * Generating non-repeating random numbers
 *
 * @param {Array} arr
 * @returns new array
 */
declare function shuffle(arr: any[]): any[];
