# @/components/Footer

![MIT license](https://badgen.now.sh/badge/license/MIT)

[Source](https://github.com/xizon/fullstack-nextjs-app-template/tree/main/src/components/Footer)


## Examples

```js
import React from 'react';
import Footer from '@/components/Footer';


export default () => {
  return (
    <>
		<Footer />
    </>
  );
}

```