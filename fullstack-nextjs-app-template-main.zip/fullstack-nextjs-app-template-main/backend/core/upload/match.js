/**
 * Image file type and format (include extension)
 */
const imgIncludeExtTypes = /\.(jpg|jpeg|png|gif|webp)$/i;


module.exports = {
    imgIncludeExtTypes
}     
